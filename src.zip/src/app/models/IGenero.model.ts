export interface IListaGenero {
  genres: IGenero[];
}

export interface IGenero {
  id: number;
  name: string;
}
